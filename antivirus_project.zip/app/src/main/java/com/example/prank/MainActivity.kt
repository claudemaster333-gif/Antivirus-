package com.example.prank

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Дозвіл "Поверх інших додатків" — без нього Android 10+ не дасть відкрити відео з фону
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Дай дозвіл «Поверх інших додатків» і відкрий знову", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            finish()
            return
        }

        setContentView(TextView(this).apply {
            text = "привет медвет"
            textSize = 32f
            gravity = Gravity.CENTER
        })

        val appCtx = applicationContext

        // 2 сек показуємо текст -> викидає на робочий стіл
        Handler(Looper.getMainLooper()).postDelayed({
            moveTaskToBack(true)
            // ще 2 сек на робочому столі -> відео
            Handler(Looper.getMainLooper()).postDelayed({
                appCtx.startActivity(
                    Intent(appCtx, VideoActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }, 2000)
        }, 2000)
    }
}
