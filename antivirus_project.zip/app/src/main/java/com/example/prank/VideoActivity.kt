package com.example.prank

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class VideoActivity : AppCompatActivity() {

    companion object {
        const val VOLUME_PERCENT = 20      // на скільки % від максимуму підкручувати звук
        const val VOLUME_UP_PRESSES = 3    // скільки разів натиснути "гучність +" щоб усе закрити
    }

    private lateinit var root: FrameLayout
    private lateinit var audio: AudioManager
    private var oldVolume = 0
    private val mainHandler = Handler(Looper.getMainLooper())
    private val volPresses = ArrayList<Long>()
    private var game: GameView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)

        // Підкручуємо звук (лише вгору, і запам'ятовуємо старий рівень)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        oldVolume = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        val target = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * VOLUME_PERCENT / 100
        if (oldVolume < target) audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        setContentView(root)
        playFull(R.raw.scream) { playFull(R.raw.boss) { root.post { startFight() } } }
    }

    private fun playFull(res: Int, onDone: () -> Unit) {
        root.removeAllViews()
        val v = VideoView(this)
        root.addView(v, FrameLayout.LayoutParams(-1, -1))
        v.setVideoURI(Uri.parse("android.resource://$packageName/$res"))
        v.setOnCompletionListener { onDone() }
        v.setOnErrorListener { _, _, _ -> onDone(); true }
        v.start()
    }

    private fun startFight() {
        root.removeAllViews()
        game = GameView(this, root.width, root.height).also {
            root.addView(it, FrameLayout.LayoutParams(-1, -1))
            it.start()
        }
    }

    // 3 рази "гучність +" за 3 секунди = закрити все
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            if (event.repeatCount == 0) {
                val now = SystemClock.uptimeMillis()
                volPresses.add(now)
                volPresses.removeAll { now - it > 3000 }
                if (volPresses.size >= VOLUME_UP_PRESSES) finish()
            }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        game?.stop()
        mainHandler.removeCallbacksAndMessages(null)
        runCatching { audio.setStreamVolume(AudioManager.STREAM_MUSIC, oldVolume, 0) }
        super.onDestroy()
    }

    // ───────────────────────── БОССФАЙТ ─────────────────────────
    // Ти керуєш відео-скрімером (тягни пальцем), воно саме стріляє.
    // Бос - відео з Наротаном, ходить вліво-вправо і кидає в тебе кульки.
    inner class GameView(ctx: Context, private val w: Int, private val h: Int) : FrameLayout(ctx) {
        private val d = resources.displayMetrics.density
        private val bossW = (w * 0.45f).toInt(); private val bossH = (bossW * 16 / 9f).toInt()
        private val plW = (w * 0.20f).toInt();   private val plH = (plW * 16 / 9f).toInt()

        private val boss = VideoView(ctx); private val player = VideoView(ctx)
        private val overlay = Overlay(ctx)

        private var bossX = 0f; private var bossDir = 1
        private var plX = (w - plW) / 2f; private var plY = h - plH - 40 * d
        private var bossHp = 100; private var lives = 3
        private val myShots = ArrayList<RectF>(); private val bossShots = ArrayList<RectF>()
        private var lastMyShot = 0L; private var lastBossShot = 0L
        private var msg = ""; private var msgUntil = 0L
        private var won = false; private var running = true
        private var last = SystemClock.uptimeMillis()
        private val topY = 30 * d

        init {
            for (v in listOf(boss, player)) { v.setZOrderMediaOverlay(true) }
            addView(boss, LayoutParams(bossW, bossH))
            addView(player, LayoutParams(plW, plH))
            addView(overlay, LayoutParams(-1, -1))
            boss.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.boss}"))
            boss.setOnPreparedListener { it.isLooping = true }
            player.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.scream}"))
            player.setOnPreparedListener { it.isLooping = true; it.setVolume(0f, 0f) }
        }

        fun start() { boss.start(); player.start(); tick.run() }
        fun stop() { running = false; mainHandler.removeCallbacks(tick) }

        private val tick = object : Runnable {
            override fun run() {
                if (!running) return
                val now = SystemClock.uptimeMillis()
                val dt = (now - last).coerceAtMost(50); last = now
                update(dt, now)
                boss.x = bossX; boss.y = topY
                player.x = plX; player.y = plY
                overlay.invalidate()
                mainHandler.postDelayed(this, 16)
            }
        }

        private fun update(dt: Long, now: Long) {
            if (won) return
            // бос ходить
            bossX += bossDir * w * 0.0003f * dt
            if (bossX < 0) { bossX = 0f; bossDir = 1 }
            if (bossX > w - bossW) { bossX = (w - bossW).toFloat(); bossDir = -1 }

            // ти стріляєш автоматично
            if (now - lastMyShot > 260) {
                lastMyShot = now
                val cx = plX + plW / 2f
                myShots.add(RectF(cx - 5 * d, plY - 24 * d, cx + 5 * d, plY))
            }
            // бос стріляє
            if (now - lastBossShot > 850) {
                lastBossShot = now
                val cx = bossX + bossW / 2f + Random.nextInt(-bossW / 3, bossW / 3)
                val by = topY + bossH * 0.8f
                bossShots.add(RectF(cx - 9 * d, by, cx + 9 * d, by + 18 * d))
            }
            val up = h * 0.0011f * dt; val down = h * 0.0007f * dt
            val bossRect = RectF(bossX + bossW * 0.1f, topY, bossX + bossW * 0.9f, topY + bossH)
            val me = RectF(plX + plW * 0.2f, plY + plH * 0.1f, plX + plW * 0.8f, plY + plH)

            val i1 = myShots.iterator()
            while (i1.hasNext()) {
                val s = i1.next(); s.offset(0f, -up)
                if (RectF.intersects(s, bossRect)) { i1.remove(); bossHp -= 2 }
                else if (s.bottom < 0) i1.remove()
            }
            val i2 = bossShots.iterator()
            while (i2.hasNext()) {
                val s = i2.next(); s.offset(0f, down)
                if (RectF.intersects(s, me)) { i2.remove(); lives-- }
                else if (s.top > h) i2.remove()
            }
            if (bossHp <= 0) {
                won = true; msg = "ПЕРЕМОГА!"; msgUntil = Long.MAX_VALUE
                mainHandler.postDelayed({ finish() }, 1800)
            } else if (lives <= 0) {
                bossHp = 100; lives = 3; myShots.clear(); bossShots.clear()
                msg = "ПРОГРАВ! ЩЕ РАЗ!"; msgUntil = now + 1200
            }
        }

        inner class Overlay(ctx: Context) : View(ctx) {
            private val p = Paint(Paint.ANTI_ALIAS_FLAG)
            override fun onDraw(c: Canvas) {
                p.color = Color.YELLOW; for (s in myShots) c.drawRect(s, p)
                p.color = Color.RED; for (s in bossShots) c.drawOval(s, p)
                // HP боса
                p.color = Color.argb(160, 0, 0, 0); c.drawRect(20 * d, 8 * d, w - 20 * d, 24 * d, p)
                p.color = Color.RED; c.drawRect(20 * d, 8 * d, 20 * d + (w - 40 * d) * bossHp.coerceAtLeast(0) / 100f, 24 * d, p)
                // життя
                p.color = Color.WHITE; p.textSize = 22 * d
                c.drawText("♥".repeat(lives.coerceAtLeast(0)), 20 * d, h - 12 * d, p)
                if (SystemClock.uptimeMillis() < msgUntil) {
                    p.textSize = 40 * d; p.textAlign = Paint.Align.CENTER; p.color = Color.WHITE
                    c.drawText(msg, w / 2f, h / 2f, p); p.textAlign = Paint.Align.LEFT
                }
            }
            override fun onTouchEvent(e: MotionEvent): Boolean {
                plX = (e.x - plW / 2f).coerceIn(0f, (w - plW).toFloat())
                plY = (e.y - plH / 2f - 60 * d).coerceIn(h * 0.5f, h - plH - 10 * d)
                return true
            }
        }
    }
}
